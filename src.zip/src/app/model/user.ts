export class User {
    id : string;
    fname:string;
    lname:string;
    email:string;
    loginid:string;
    pwd:string;
    cpwd:string;
    phone:string;
}
