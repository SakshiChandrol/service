import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Tweet } from '../model/tweet';
import { User } from '../model/user';

const headerOption = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class TweetService {
  constructor(private http:HttpClient) { }

  getTweets() {
    return this.http.get<Tweet[]>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/gettweet");
  }
  getAllTweets(userid:string):Observable<Tweet[]>
   {
    
    return this.http.get<Tweet[]>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/getbyuserid/"+userid);
   }
   onViewReply(userid:string,id :string) : Observable<any>{ 
    return this.http.get<Tweet[]>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/getreplyed/"+userid+"/replyed/"+id);
  }

  onPost(tweet: Tweet,userid:string) : Observable<any>{
    return this.http.post<Tweet>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/posttweet/"+userid+"/add",tweet);
  }
  onReply(tweet: Tweet,userid:string,id:string) : Observable<any>{
    return this.http.post<Tweet>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/replytweet/"+userid+"/reply/"+id,tweet);
  }
  onEdit(tweet: Tweet,userid:string,id :string) : Observable<any>{ 
    return this.http.put<Tweet>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/onedit/"+userid+"/update/"+id,tweet);
  }
  onLike(tweet: Tweet,userid:string,id :string) : Observable<any>{ 
    return this.http.put<Tweet>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/onlike/"+userid+"/like/"+id,tweet);
  }
  onDelete(userid:string,id :string) : Observable<any>{ 
    return this.http.delete<Tweet>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/deletetweet/"+userid+"/delete/"+id);
  }

}
