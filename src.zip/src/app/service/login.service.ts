import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../model/login';

const headerOption = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient) { }

  onLogin(login:Login) {
    return this.http.post("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/login",login);
  }
  onForget(userid:string, pwd:string) {
    return this.http.put<string>("https://5zqqababuf.execute-api.ap-south-1.amazonaws.com/dev/forget/"+userid+"/forget",pwd);
  }
  
}
